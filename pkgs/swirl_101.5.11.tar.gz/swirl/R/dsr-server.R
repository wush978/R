.get.servers <- function() {
  servers <- getOption("SWIRL_TRACKING_SERVER_IP", NULL)
  if (is.null(servers)) return(NULL)
  servers <- unlist(strsplit(servers, ","))
  servers <- sample(servers, length(servers), FALSE)
  servers
}