#'@import Rcpp
#'@useDynLib FastROC
.onLoad <- function(libname, pkgname) {
  
}