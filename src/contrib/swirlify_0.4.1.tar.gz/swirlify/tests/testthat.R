library(testthat)
library(swirlify)

test_check("swirlify")
