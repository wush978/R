hw5_2_answer <- function() {
  e <- get("e", parent.frame())
  .e <- new.env()
  source_result <- try(source(e$script_temp_path, local = .e, encoding = "UTF-8"), silent = TRUE)
  if (class(source_result)[1] == "try-error") return(FALSE)
  answer <- .e$Lucas
  if (is.null(answer)) {
    cat("Cannot find Lucas in your answer\n")
    return(FALSE)
  }
  if (!is.numeric(answer)) {
    cat("class(Lucas) is not numeric\n")
    return(FALSE)
  }
  answer.ref <- numeric(100)
  answer.ref[1] <- 2
  answer.ref[2] <- 1
  for(i in 1:98) answer.ref[i+2] <- answer.ref[i] + answer.ref[i + 1]
  if (length(answer) != length(answer.ref)) {
    cat(sprintf("length(Lucas) is not %d\n", length(answer.ref)))
    return(FALSE)
  }
  for(i in seq_along(answer.ref)) {
    if (!isTRUE(as.vector((answer.ref[i] == answer[i])))) {
      cat(sprintf("Lucas[%d] is incorrect. The expected element is %s\n", i, answer.ref[i]))
      return(FALSE)
    }
  }
  TRUE
}