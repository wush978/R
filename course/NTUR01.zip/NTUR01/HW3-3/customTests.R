hw3_3_answer <- function() {
  e <- get("e", parent.frame())
  .e <- new.env()
  source_result <- try(source(e$script_temp_path, local = .e, encoding = "UTF-8"), silent = TRUE)
  if (class(source_result)[1] == "try-error") return(FALSE)
  answer <- .e$answer3_3
  if (is.null(answer)) {
    cat("Cannot find answer3_3 in your answer\n")
    return(FALSE)
  }
  if (!is.list(answer)) {
    cat("class(answer3_3) is not list\n")
    return(FALSE)
  }
  answer.ref <- list(1, a = paste(2:4), "3" = 3:9)
  if (length(answer) != length(answer.ref)) {
    cat("length(answer3_3) is not 3\n")
    return(FALSE)
  }
  for(i in seq_along(answer.ref)) {
    if (class(answer[[i]]) != class(answer.ref[[i]])) {
      cat(sprintf("class(answer3_3[[%d]]) is incorrect. The expected result is %s\n", i, class(answer.ref[[i]])))
      return(FALSE)
    }
    if (length(answer[[i]]) != length(answer.ref[[i]])) {
      cat(sprintf("length(answer[[i]]) is incorrect. The expected result is %d\n", i, length(answer.ref[[i]])))
      return(FALSE)
    }
    for(j in seq_along(answer[[i]])) {
      if (!isTRUE(answer.ref[[i]][j] == answer[[i]][j])) {
        cat(sprintf("answer3_3[[%d]][%d] is incorrect. The expected element is %s\n", i, j, answer.ref[[i]][j]))
        return(FALSE)
      }
    }
  }
  if (!isTRUE(all.equal(sort(names(attributes(answer))), sort(names(attributes(answer.ref)))))) {
    cat("The attribute of answer3_3 is incorrect. The expected element is %s\n", paste(sort(names(attributes(answer.ref))), collapse = ","))
    return(FALSE)
  }
  .a1 <- attributes(answer)[sort(names(attributes(answer)))]
  .a2 <- attributes(answer.ref)[sort(names(attributes(answer.ref)))]
  if (!isTRUE(all.equal(.a1, .a2))) {
    cat("The attributes of answer3_3 is incorrect.\n")
    return(FALSE)
  }
  TRUE
}