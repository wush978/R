#' 請同學先閱讀以下的說明
#' 
#' 變數`web_log`中是一段網頁伺服器的記錄
#' 同學可以先在console把它印出來看看
web_log

#' 其中每一行的最後一個整數，代表的是網頁伺服器傳送出去的檔案大小。
#' ps. 若同學對處理這類資料有興趣，可以自行瞭解每一行中每段文字的資訊。
#'     這部分要閱讀官方文件： <https://httpd.apache.org/docs/2.4/logs.html>
#' 我們可以利用以下的Expression切割web_log中的空白：
web_log.tokens <- strsplit(web_log, " ", fixed = TRUE)

#' 接下來，我們要取得每一筆記錄中傳送出去的檔案大小。
#' 我們先建立一個變數`web_log.filesize`
web_log.filesize <- numeric(length(web_log.tokens))

#' 這裡老師寫出一段expression，
#' 從web_log.tokens中取得第一筆紀錄中，傳輸的檔案大小
#' 把結果存到`web_log.filesize[1]` 
web_log.filesize[1] <- as.numeric(web_log.tokens[[1]][10])

#' 請同學寫出一段expression，
#' 從web_log.tokens中取得第二筆紀錄中，傳輸的檔案大小
#' 把結果存到`web_log.filesize[2]` 
web_log.filesize[2] <- <請寫出你的程式碼>

#' 以下的程式碼先檢查`web_log.filesize[2]`，請同學不要修改
stopifnot(is.numeric(web_log.filesize))
stopifnot(web_log.filesize[2] == 4523)
stopifnot(length(web_log.filesize) == length(web_log.tokens))

#' 請同學比較自己寫出來的兩段Expression，並且把變動的部分改成用變數`i`

# 從web_log.tokens中取得第一筆紀錄中，傳輸的檔案大小
i <- 1
<你的Expression>
# 從web_log.tokens中取得第二筆紀錄中，傳輸的檔案大小
i <- 2
<你的Expression>

#' 上述同學填入兩個`<你的Expression>`的結果要完全相同

#' 接下來，請同學用迴圈完成變數`web_log.filesize`
for(i in 1:length(web_log.tokens)) {
  <你的Expression>
}

#' 以下的程式碼檢查變數`web_log.filesize`
stopifnot(is.numeric(web_log.filesize))
stopifnot(web_log.filesize[1] == 12846)
stopifnot(web_log.filesize[2] == 4523)
stopifnot(length(web_log.filesize) == length(web_log.tokens))

#' 在寫迴圈整理資料之後，檢查自己計算的結果是很重要的。
#' 請同學印出`web_log.filesize`
web_log.filesize

#' 同學有沒有注意到最後若干個元素是NA？
#' 為什麼這些元素是NA呢？請同學自行思考與探索
#' 最後老師請同學在不影響結果的順序之下，把這些NA的元素從答案中拿掉
<你的expression>

#' 以下的程式碼檢查變數`web_log.filesize`
stopifnot(web_log.filesize[1] == 12846)
stopifnot(web_log.filesize[2] == 4523)
stopifnot(sum(is.na(web_log.filesize)) == 0)
