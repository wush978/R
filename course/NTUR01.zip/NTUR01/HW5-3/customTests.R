hw5_3_answer <- function() {
  e <- get("e", parent.frame())
  .e <- new.env()
  source_result <- try(source(e$script_temp_path, local = .e, encoding = "UTF-8"), silent = TRUE)
  if (class(source_result)[1] == "try-error") return(FALSE)
  answer <- .e$web_log.filesize
  if (is.null(answer)) {
    cat("Cannot find web_log.filesize in your answer\n")
    return(FALSE)
  }
  if (!is.numeric(answer)) {
    cat("class(web_log.filesize) is not numeric\n")
    return(FALSE)
  }
  web_log <- readLines(normalizePath(file.path(e$path, "web.log"), mustWork = TRUE))
  web_log.tokens <- strsplit(web_log, " ", fixed = TRUE)
  answer.ref <- numeric(length((web_log.tokens)))
  for(i in 1:length(web_log.tokens)) answer.ref[i] <- as.numeric(web_log.tokens[[i]][10])
  answer.ref <- answer.ref[!is.na(answer.ref)]
  if (length(answer) != length(answer.ref)) {
    cat(sprintf("length(web_log.filesize) is not %d\n", length(answer.ref)))
    return(FALSE)
  }
  for(i in seq_along(answer.ref)) {
    if (!isTRUE(as.vector((answer.ref[i] == answer[i])))) {
      cat(sprintf("web_log.filesize[%d] is incorrect. The expected element is %s\n", i, answer.ref[i]))
      return(FALSE)
    }
  }
  TRUE
}