assign("web_log", 
       readLines(normalizePath(file.path(lesPath, "web.log"), mustWork = TRUE)),
       envir = globalenv())