assign("density_path", 
       normalizePath(file.path(lesPath, "density"), mustWork = TRUE),
       envir = globalenv())