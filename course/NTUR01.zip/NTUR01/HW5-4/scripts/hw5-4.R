#' 請同學先閱讀以下的說明
#' 
#' 變數`density_path`是課程中的一個目錄，
#' 裡面有從<https://data.gov.tw/dataset/8410>下載的
#' 自民國102年到民國106年的個鄉鎮人口密度
#' 同學可以用以下的expression印出該目錄底下的所有下載的檔案
dir(density_path, full.names = TRUE)

#' 我們先把上面的結果儲存到變數`file_list`
file_list <- dir(density_path, full.names = TRUE)

#' `file_list`是一個字串向量，每一個元素代表一個檔案
#' 當我們有`file_list`之後，就可以寫迴圈來一次讀取所有的檔案
#' 我們先建立變數`density_contents`
#' 在讀取檔案時，因為檔案內容的多變性，通常會用list來做處理
density_contents <- vector("list", length(file_list))

#' 作業中，同學可以看到老師每次寫迴圈**之前**，都會先建立好
#' 存放最後結果的R物件
#' **然後再寫迴圈**
#' 這是寫迴圈時很常見的模式

#' 老師讀取第一個檔案給同學當範例：
. <- file(file_list[1], encoding = "UTF-8")
. <- readLines(.)
. <- textConnection(.)
density_contents[[1]] <- read.csv(., header = TRUE, skip = 1, nrow = 368)

#' 請同學參考上述的程式碼，直接寫迴圈，完成`density_contents`
for(i in 1:length(file_list)) {
  <你的Expression>
}

#' 以下是檢查`density_contents`的程式碼
stopifnot(is.list(density_contents))
stopifnot(length(density_contents) == length(file_list))
for(i in seq_along(density_contents)) stopifnot(is.data.frame(density_contents[[i]]))

#' 實務上，如果`density_contents`裡面的表格欄位都相同
#' （所有的表格的欄位依序是：統計年、區域別、年底人口數...）
#' 可以用`do.call(what = rbind, density_contents)`直接把所有的表格
#' 合併成一個單一表格做處理