hw3_1_answer <- function() {
  e <- get("e", parent.frame())
  .e <- new.env()
  source_result <- try(source(e$script_temp_path, local = .e, encoding = "UTF-8"), silent = TRUE)
  if (class(source_result)[1] == "try-error") return(FALSE)
  answer <- .e$answer3_1
  if (is.null(answer)) {
    cat("Cannot find answer3_1 in your answer\n")
    return(FALSE)
  }
  if (!is.integer(answer)) {
    cat("class(answer3_1) is not integer\n")
    return(FALSE)
  }
  answer.ref <- 1:10
  if (length(answer) != length(answer.ref)) {
    cat("length(answer3_1) is not 10\n")
    return(FALSE)
  }
  for(i in seq_along(answer.ref)) {
    if (!isTRUE(answer.ref[i] == answer[i])) {
      cat(sprintf("answer3_1[%d] is incorrect. The expected element is %s\n", i, answer.ref[i]))
      return(FALSE)
    }
  }
  TRUE
}