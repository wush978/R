hw5_6_answer <- function() {
  e <- get("e", parent.frame())
  .e <- new.env()
  source_result <- try(source(e$script_temp_path, local = .e, encoding = "UTF-8"), silent = TRUE)
  if (class(source_result)[1] == "try-error") return(FALSE)
  door_open <- .e$door_open
  get_door_switch <- .e$get_door_switch
  get_door_no_switch <- .e$get_door_no_switch
  if (is.null(door_open)) {
    cat(sprintf("There is no door_open in your answer!\n"))
    return(FALSE)
  }
  if (is.null(get_door_switch)) {
    cat(sprintf("There is no get_door_switch in your answer!\n"))
    return(FALSE)
  }
  if (is.null(get_door_no_switch)) {
    cat(sprintf("There is no get_door_no_switch in your answer!\n"))
    return(FALSE)
  }
  if (!is.numeric(door_open)) {
    cat(sprintf("door_open is not a numeric vector\n"))
    return(FALSE)
  }
  if (!is.function(get_door_switch)) {
    cat(sprintf("get_door_switch is not a function\n"))
    return(FALSE)
  }
  if (!is.function(get_door_no_switch)) {
    cat(sprintf("get_door_no_switch is not a function\n"))
    return(FALSE)
  }
  # check door_open
  door_guess <- .e$door_guess
  door_answer <- .e$door_answer
  if (is.null(door_guess)) {
    cat(sprintf("There is no door_guess in your answer!\n"))
    return(FALSE)
  }
  if (is.null(door_answer)) {
    cat(sprintf("There is no door_answer in your answer!\n"))
    return(FALSE)
  }
  if (length(door_open) != 100) {
    cat(sprintf("length(door_open) should be 100\n"))
    return(FALSE)
  }
  if (length(door_guess) != 100) {
    cat(sprintf("length(door_guess) should be 100\n"))
    return(FALSE)
  }
  if (length(door_answer) != 100) {
    cat(sprintf("length(door_answer) should be 100\n"))
    return(FALSE)
  }
  if (!all(door_open %in% 1:3)) {
    cat(sprintf("door_open should be 1, 2, or 3\n"))
    return(FALSE)
  }
  if (!all(door_guess %in% 1:3)) {
    cat(sprintf("door_guess should be 1, 2, or 3\n"))
    return(FALSE)
  }
  if (!all(door_answer %in% 1:3)) {
    cat(sprintf("door_answer should be 1, 2, or 3\n"))
    return(FALSE)
  }
  if (any(door_open == door_guess)) {
    cat(sprintf("door_open should not be equal to door_guess\n"))
    return(FALSE)
  }
  if (any(door_open == door_answer)) {
    cat(sprintf("door_open should not be equal to door_answer\n"))
    return(FALSE)
  }
  
  .df <- expand.grid(guess = 1:3, open = 1:3)
  .df <- .df[.df$guess != .df$open,]
  .door_switch <- get_door_switch(.df$guess, .df$open)
  .door_no_switch <- get_door_no_switch(.df$guess, .df$open)
  if (!is.numeric(.door_switch)) {
    cat(sprintf("get_door_switch returns non-numeric answer\n"))
    return(FALSE)
  }
  if (length(.door_switch) != nrow(.df)) {
    cat(sprintf("length of the result of get_door_switch is inconsistent\n"))
    return(FALSE)
  }
  if (!is.numeric(.door_no_switch)) {
    cat(sprintf("get_door_no_switch returns non-numeric answer\n"))
    return(FALSE)
  }
  if (length(.door_no_switch) != nrow(.df)) {
    cat(sprintf("length of the result of get_door_no_switch is inconsistent\n"))
    return(FALSE)
  }
  if (!all(.door_switch == c(3, 2, 3, 1, 2, 1))) {
    cat(sprintf("Your answer of get_door_switch is incorrect\n"))
    return(FALSE)
  }
  if (!all(.door_no_switch == .df$guess)) {
    cat(sprintf("Your answer of get_door_no_switch is incorrect\n"))
    return(FALSE)
  }
  TRUE
}
