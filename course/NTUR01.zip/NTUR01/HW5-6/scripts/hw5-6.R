#' 在之前的作業中，同學有看到一個關於三門問題的範例
#' 這個作業中會帶著同學利用for與if建立一個三門問題的模擬結果
#' 
#' 三門問題的玩法是這樣子。
#' 參賽者會看見三扇關閉的門，其中一扇門的後面有一輛汽車或者是獎品。
#' 在R 之中，我們可以利用一個數值向量，每個向量得值為1, 2, 或 3，來代表
#' 藏有答案的門。
#' 如果主辦單位是均勻的隨機決定藏有答案的門，那我們可以利用`sample`函數模擬
#' 100次可能的遊戲解答：
door_answer <- sample(1:3, 100, TRUE)

#' 其中，`door_answer[1]`代表第一次遊戲時，哪一扇們背後有解答。
#' 其中，`door_answer[2]`代表第二次遊戲時，哪一扇們背後有解答。
#' 以此類推

#' 假設參賽者不知道答案，也是隨機猜一扇門
#' 我們可以用一樣的expression來模擬100次參賽者猜的答案：
door_guess <- sample(1:3, 100, TRUE)
#' 其中，`door_guess[1]`代表第一次遊戲時，參賽者猜測哪一扇們背後有解答。
#' 其中，`door_guess[2]`代表第二次遊戲時，參賽者猜測哪一扇們背後有解答。
#' 以此類推

#' 在參賽者給出猜測的答案之後，主持人會從剩下的兩扇門之中，隨機打開一扇
#' 沒有答案的門，並且詢問參賽者要不要更換答案。
#' 由於打開一扇門之後，剩下兩扇門還沒打開，所以此時參賽者陷入二選一（換或不換）
#' 我們先建立一個向量`door_open`代表在這100次遊戲時，主持人打開來給參賽者看的門。
door_open <- numeric(100)

#' 現在我們假設在第一次遊戲
#' 如果參賽者猜中了，主持人要從剩下兩張沒有獎品的門中隨機開啟一張
if (door_answer[1] == door_guess[1]) {
  door_open[1] <- sample(setdiff(1:3, door_answer[1]), 1)
}
#' 如果參賽者沒猜中，主持人要打開剩下唯一的沒有獎品的門
if (door_answer[1] != door_guess[1]) {
  # `setdiff`函數會從第一個參數中刪除第二個參數中的元素，並且回傳結果
  door_open[1] <- setdiff(1:3, c(door_guess[1], door_answer[1]))
}
#' 請同學利用迴圈，產生一個`door_open`向量，結果是100次主持人打開的那扇門

#' 以下的程式碼檢查你的答案
stopifnot(length(door_open) == 100)
# 打開的門不能是答案
stopifnot(door_open != door_answer)
# 打開的門不能和參賽者猜的相同
stopifnot(door_open != door_guess)

#' 如果參賽者選擇「換」，請同學依據door_answer, door_guess, 與door_open 
#' 利用迴圈寫出最後參賽者選出來的門
#' 並且把這個過程包裝成一個名為get_door_switch的函數
get_door_switch <- function(door_guess, door_open) {
  door_switch <- numeric(length(door_guess))
  for(i in 1:length(door_guess)) {
    <你的Expression>
  }
  # 回傳door_switch
  door_switch  
}

#' 如果參賽者選擇「不換」，請同學依據door_answer, door_guess, 與door_open 
#' 利用迴圈寫出最後參賽者選出來的門
#' 並且把這個過程包裝成一個名為get_door_no_switch的函數
get_door_no_switch <- function(door_guess, door_open) {
  door_no_switch <- numeric(length(door_guess))
  for(i in 1:length(door_guess)) {
    <你的Expression>
  }
  # 回傳door_no_switch
  door_no_switch  
}

#' 如果同學寫的函數正確，我們可以利用`mean`函數計算參賽者在兩種策略下
#' 獲得獎品的機率：
mean(door_answer == get_door_switch(door_guess, door_open))
mean(door_answer == get_door_no_switch(door_guess, door_open))

#' 以下的程式碼檢查同學的答案
stopifnot(is.function(get_door_switch))
#' 如果參賽者猜第二扇門、主持人打開第三扇門，
#' 則get_door_switch應該回傳第一扇門
stopifnot(get_door_switch(c(2), c(3)) == c(1))
#' 如果第二次遊戲時，
#' 參賽者猜第一扇門、主持人打開第三扇門，
#' 則get_door_switch應該回傳第二扇門
stopifnot(get_door_switch(c(2, 1), c(3, 3)) == c(1, 2))

stopifnot(is.function(get_door_no_switch))
#' 如果參賽者猜第二扇門、主持人打開第三扇門，
#' 則get_door_switch應該回傳第一扇門
stopifnot(get_door_no_switch(c(2), c(3)) == c(2))
#' 如果第二次遊戲時，
#' 參賽者猜第一扇門、主持人打開第三扇門，
#' 則get_door_switch應該回傳第二扇門
stopifnot(get_door_no_switch(c(2, 1), c(3, 3)) == c(2, 1))
