#' 請同學先閱讀以下的說明
#' 
#' 變數`density_path`是課程中的一個目錄，
#' 裡面有從<https://data.gov.tw/dataset/8410>下載的
#' 自民國102年到民國106年的個鄉鎮人口密度
#' 同學可以用以下的expression印出該目錄底下的所有下載的檔案
dir(density_path, full.names = TRUE)

#' 我們先把上面的結果儲存到變數`file_list`
file_list <- dir(density_path, full.names = TRUE)

#' 上一題中，我們用迴圈來讀取資料。
#' 這一題，我們用`lapply`函數來讀取資料。
#' lapply函數與for迴圈很接近，但是它會自動幫我們建立儲存結果的list，
#' 並且需要我們把for迴圈中的expression變成函數。
#' 首先，請同學修改以下的expression，
#' 讓他成為一個可以讀取人口密度檔案的函數：


#' 以下的註解，是關於`read_density`的函數說明
#' title 是用途
#' param 是函數的參數
#' return 是函數的結果
#'
#'@title 讀取人口密度
#'@param path 字串函數。從<https://data.gov.tw/dataset/8410>中下載的檔案的路徑。
#'@return 一個data.frame
#'
read_density <- function(path) {
  # 以下是老師在HW5-4給的範例expression
  # 請將代表檔案路徑的參數換成`path`，讓輸出結果會根據`path`來讀取不同的檔案
  . <- file(file_list[1], encoding = "UTF-8")
  . <- readLines(.)
  . <- textConnection(.)
  read.csv(., header = TRUE, skip = 1, nrow = 368)
}

#' 以下是檢查`read_density`函數的程式碼
stopifnot(is.data.frame(read_density(file_list[1])))
stopifnot(is.data.frame(read_density(file_list[2])))
stopifnot(read_density(file_list[1])[[3]][1] == 554236)
stopifnot(read_density(file_list[2])[[3]][1] == 556920)

#' 要得到HW5-4的結果，透過`lapply`與我們寫的`read_density`，
#' 只要執行：
density_contents <- lapply(file_list, read_density)
#' 就可以得到答案了
