hw5_5_answer <- function() {
  e <- get("e", parent.frame())
  .e <- new.env()
  source_result <- try(source(e$script_temp_path, local = .e, encoding = "UTF-8"), silent = TRUE)
  if (class(source_result)[1] == "try-error") return(FALSE)
  answer <- .e$density_contents
  if (is.null(answer)) {
    cat("Cannot find density_contents in your answer\n")
    return(FALSE)
  }
  if (!is.list(answer)) {
    cat("class(density_contents) is not list\n")
    return(FALSE)
  }
  answer.ref <- lapply(
    dir(normalizePath(file.path(e$path, "density")), full.names = TRUE),
    function(path) {
      . <- file(path, encoding = "UTF-8")
      . <- readLines(.)
      . <- textConnection(.)
      read.csv(., header = TRUE, skip = 1, nrow = 368)
    }
  )
  if (length(answer) != length(answer.ref)) {
    cat(sprintf("length(density_contents) is not %d\n", length(answer.ref)))
    return(FALSE)
  }
  for(i in seq_along(answer.ref)) {
    if (!is.data.frame(answer[[i]])) {
      cat(sprintf("density_contents[[%d]] is not a data.frame\n", i))
      return(FALSE)
    }
    if (!isTRUE(all.equal(answer.ref[[i]], answer[[i]]))) {
      cat(sprintf("density_contents[[i]] is incorrect. Please use the expression I give to read the file.\n", i))
      return(FALSE)
    }
  }
  TRUE
}
