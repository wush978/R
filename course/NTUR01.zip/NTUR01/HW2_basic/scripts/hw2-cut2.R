#' 請同學依照指示撰寫R的expression計算以下的問題。
#' 請把程式碼寫在 <請填寫你的程式碼> 的部份。
#' 寫完之後請記得「存擋」 
#' 寫完之後請記得「存擋」 
#' 寫完之後請記得「存擋」
#' 然後在console輸入`submit()`讓老師檢查答案 
#' 所有的答案都要算對，才會算分

## 題目開始

#' 請同學依以answer2為分割點，運用`cut`重新將`hw2_age`作分組。
#' 請注意，最小值應該被分到第一組，而不是 NA
answer3 <- cut(<請填寫你的程式碼>)

#' 以下的程式碼中，老師會幫同學整理answer3的資料作比對，以及檢查answer3的型態
#' 請不要修改下面的程式碼
#' 同學也可以閱讀下面的程式碼，來獲得答案的提示
stopifnot(is.factor(answer3)) # cut 的輸出是 factor
stopifnot(length(answer3) == length(hw2_age))
answer3 <- as.character(answer3) # 老師把同學的答案轉成字串再對答案
stopifnot(answer3[1] == "(32.6,36]") 
