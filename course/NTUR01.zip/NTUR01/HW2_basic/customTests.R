hw2_basic_cut <- function() {
  e <- get("e", parent.frame())
  .e <- new.env()
  source_result <- try(source(e$script_temp_path, local = .e, encoding = "UTF-8"), silent = TRUE)
  if (class(source_result)[1] == "try-error") return(FALSE)
  answer1 <- .e$answer1
  if (is.null(answer1)) {
    cat("Cannot find answer1 in your answer\n")
    return(FALSE)
  }
  if (!is.character(answer1)) {
    cat("class(answer1) is not character\n")
    return(FALSE)
  }
  answer1.ref <- c("[30,40)", "[30,40)", "[40,50)", "[10,20)", "[30,40)", "[30,40)", 
                   "[30,40)", "[40,50)", "[40,50)", "[40,50)", "[20,30)", "[30,40)", 
                   "[20,30)", "[20,30)", "[30,40)", "[50,60)", "[40,50)", "[40,50)", 
                   "[50,60)", "[30,40)", "[30,40)", "[30,40)", "[50,60)", "[20,30)", 
                   "[20,30)", "[30,40)", "[30,40)", "[20,30)", "[30,40)", "[30,40)", 
                   "[30,40)", "[30,40)", "[20,30)", "[20,30)", "[40,50)", "[20,30)", 
                   "[30,40)", "[30,40)", "[30,40)", "[10,20)", "[30,40)", "[30,40)", 
                   "[30,40)", "[20,30)", "[30,40)", "[0,10)", "[60,70)", "[10,20)", 
                   "[40,50)", "[40,50)", "[10,20)", "[50,60)", "[60,70)", "[30,40)", 
                   "[30,40)", "[50,60)", "[50,60)", "[20,30)", "[40,50)", "[40,50)", 
                   "[20,30)", "[10,20)", "[20,30)", "[20,30)", "[60,70)", "[20,30)", 
                   "[30,40)", "[40,50)", "[50,60)", "[40,50)", "[40,50)", "[30,40)", 
                   "[50,60)", "[30,40)", "[40,50)", "[40,50)", "[40,50)", "[50,60)", 
                   "[10,20)", "[10,20)", "[20,30)", "[10,20)", "[30,40)", "[50,60)", 
                   "[20,30)", "[60,70)", "[20,30)", "[40,50)", "[20,30)", "[10,20)", 
                   "[30,40)", "[40,50)", "[40,50)", "[30,40)", "[30,40)", "[40,50)", 
                   "[40,50)", "[40,50)", "[20,30)", "[20,30)")
  if (length(answer1) != length(answer1.ref)) {
    cat("length(answer1) is incorrect\n")
    return(FALSE)
  }
  for(i in seq_along(answer1.ref)) {
    if (!isTRUE(answer1[i] == answer1.ref[i])) {
      cat(sprintf("answer1[%d] is incorrect, the expected value is %s\n", i, answer1.ref[i]))
      return(FALSE)
    }
  }
  TRUE
}

hw2_basic_quantile <- function() {
  e <- get("e", parent.frame())
  .e <- new.env()
  source_result <- try(source(e$script_temp_path, local = .e, encoding = "UTF-8"), silent = TRUE)
  if (class(source_result)[1] == "try-error") return(FALSE)
  answer2 <- .e$answer2
  if (is.null(answer2)) {
    cat("Cannot find answer2 in your answer\n")
    return(FALSE)
  }
  answer2.ref <- quantile(globalenv()$hw2_age, seq(0, 1, 0.1))
  if (!is.numeric(answer2)) {
    cat("class(answer2) is not numeric\n")
    return(FALSE)
  }
  if (length(answer2) != length(answer2.ref)) {
    cat(sprintf("length(answer2) is not %d\n", length(answer2.ref)))
    return(FALSE)
  }
  for(i in seq_along(answer2.ref)) {
    if (!isTRUE(as.vector(answer2[i] == answer2.ref[i]))) {
      cat(sprintf("answer2[%d] is incorrect\n", i))
      return(FALSE)
    }
  }
  TRUE
}

hw2_basic_cut2 <- function() {
  e <- get("e", parent.frame())
  .e <- new.env()
  .e$answer2 <- quantile(hw2_age, seq(0, 1, 0.1))
  source_result <- try(source(e$script_temp_path, local = .e, encoding = "UTF-8"), silent = TRUE)
  if (class(source_result)[1] == "try-error") return(FALSE)
  answer3 <- .e$answer3
  if (!is.character(answer3)) {
    cat("class(answer3) is not character\n")
    return(FALSE)
  }
  answer3.ref <- cut(hw2_age, quantile(hw2_age, seq(0, 1, 0.1)), include.lowest = TRUE)
  if (length(answer3) != length(answer3.ref)) {
    cat(sprintf("length(answer3) is not %d\n", length(answer3.ref)))
    return(FALSE)
  }
  for(i in seq_along(answer3.ref)) {
    if (!isTRUE(answer3[i] == answer3.ref[i])) {
      cat(sprintf("answer3[%d] is incorrect. The expected answer is %s\n", i, answer3.ref[i]))
      return(FALSE)
    }
  }
  TRUE
}