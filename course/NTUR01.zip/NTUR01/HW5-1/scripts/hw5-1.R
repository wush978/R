#' 請同學先閱讀以下的說明
#' 
#' Fibonacci數列是一個在自然界常常出現的數學模式。
#' 有興趣的同學可以參考： <https://en.wikipedia.org/wiki/Fibonacci_sequence>
#' 他的數列的前幾個元素是：
#' 1, 1, 2, 3, 5, 7, 13, ...
#' 第一個元素是1，
#' 第二個元素也是1，
#' 之後的每個元素都是前兩個元素的相加
#' F_{n} = F_{n-1} + F_{n-2}
#' 舉例來說，1 + 1 = 2，所以第三個元素是2（第一個元素加上第二個元素）
#' 1 + 2 = 3，所以第四個元素是3（第二個元素加上第三個元素）
#' 2 + 3 = 5，所以第五個元素是5（第三個元素加上第四個元素）
#' 以下的程式會在R中計算長度10的Fibonacci數列

# 變數`Fibonacci`的長度是10
Fibonacci <- numeric(10)

#' 我們先用勤勞的方式計算前幾個Fibonacci數列的元素：

# 第一個元素是1
Fibonacci[1] <- 1
# 第二個元素是1
Fibonacci[2] <- 1
# 第三個元素是前兩個相加
Fibonacci[3] <- Fibonacci[1] + Fibonacci[2]
# 第四個元素是前兩個相加
Fibonacci[4] <- Fibonacci[2] + Fibonacci[3]
# 第五個元素是前兩個相加
Fibonacci[5] <- Fibonacci[3] + Fibonacci[4]

#' 接下來，我們嘗試把上面的算是變成迴圈

## 迴圈的初始化
#' 以下的三個Expression是沒辦法迴圈化的，因為他們的邏輯並沒有重複：
Fibonacci <- numeric(10)
Fibonacci[1] <- 1
Fibonacci[2] <- 1

#' 以下的三個Expression是可以迴圈化的，
#' 因為他們的邏輯(每個元素都是前兩個元素的相加)是一直重複下去的
Fibonacci[3] <- Fibonacci[1] + Fibonacci[2]
Fibonacci[4] <- Fibonacci[2] + Fibonacci[3]
Fibonacci[5] <- Fibonacci[3] + Fibonacci[4]

#' 首先，我們要把變動的部分找出來：
#' 同學應該很快可以觀察到，在中括號中的整數，會依序遞增
#' 所以我們要先將「變動的部分用變數取代」。
#' 我們先設定一個變數`i`得值為1
i <- 1
#' 請同學寫一個Expression等價於：`Fibonacci[3] <- Fibonacci[1] + Fibonacci[2]`
<請填寫你的答案>

#' 接下來，如果變數`i`得值為2
i <- 2
#' 請同學寫一個Expression等價於：`Fibonacci[4] <- Fibonacci[2] + Fibonacci[3]`
<請填寫你的答案>

#' 接下來，如果變數`i`得值為3
i <- 3
#' 請同學寫一個Expression等價於：`Fibonacci[5] <- Fibonacci[4] + Fibonacci[3]`
<請填寫你的答案>

#' 請同學檢查上面的三個答案，讓三個答案的Exprssion都一模一樣

#' 最後，請同學修改以下的迴圈，讓R能完成變數`Fibonacci`剩下的部分：
for(i in <請填寫你的答案>) {
  <請填寫你的答案>
}

#' 以下是對`Fibonacci`變數的檢查，請同學不要更動程式碼
stopifnot(is.numeric(Fibonacci))
stopifnot(length(Fibonacci) == 10)
stopifnot(Fibonacci[10] == 55)



