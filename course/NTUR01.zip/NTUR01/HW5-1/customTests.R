hw5_1_answer <- function() {
  e <- get("e", parent.frame())
  .e <- new.env()
  source_result <- try(source(e$script_temp_path, local = .e, encoding = "UTF-8"), silent = TRUE)
  if (class(source_result)[1] == "try-error") return(FALSE)
  answer <- .e$Fibonacci
  if (is.null(answer)) {
    cat("Cannot find Fibonacci in your answer\n")
    return(FALSE)
  }
  if (!is.numeric(answer)) {
    cat("class(Fibonacci) is not numeric\n")
    return(FALSE)
  }
  answer.ref <- c(1, 1, 2, 3, 5, 8, 13, 21, 34, 55)
  if (length(answer) != length(answer.ref)) {
    cat(sprintf("length(Fibonacci) is not %d\n", length(answer.ref)))
    return(FALSE)
  }
  for(i in seq_along(answer.ref)) {
    if (!isTRUE(as.vector((answer.ref[i] == answer[i])))) {
      cat(sprintf("Fibonacci[%d] is incorrect. The expected element is %s\n", i, answer.ref[i]))
      return(FALSE)
    }
  }
  TRUE
}