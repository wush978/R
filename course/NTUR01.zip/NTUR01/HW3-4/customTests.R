hw3_4_answer <- function() {
  e <- get("e", parent.frame())
  .e <- new.env()
  source_result <- try(source(e$script_temp_path, local = .e, encoding = "UTF-8"), silent = TRUE)
  if (class(source_result)[1] == "try-error") return(FALSE)
  answer3_4 <- .e$answer3_4
  if (is.null(answer3_4)) {
    cat("Cannot find answer3_4 in your answer\n")
    return(FALSE)
  }
  if (!is.list(answer3_4)) {
    cat("class(answer3_4) is not list\n")
    return(FALSE)
  }
  answer.ref <- list(1, list(1, 2), a = list(paste(2:4), b = 3:6))
  .r <- try(stopifnot(isTRUE(all.equal(answer3_4, answer.ref))), silent = TRUE)
  if (class(.r)[1] == "try-error") {
    cat(conditionMessage(attr(.r, "condition")))
    cat("\n")
    return(FALSE)
  }
  TRUE
}