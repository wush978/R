hw3_2_answer <- function() {
  e <- get("e", parent.frame())
  .e <- new.env()
  source_result <- try(source(e$script_temp_path, local = .e, encoding = "UTF-8"), silent = TRUE)
  if (class(source_result)[1] == "try-error") return(FALSE)
  answer <- .e$answer3_2
  if (is.null(answer)) {
    cat("Cannot find answer3_2 in your answer\n")
    return(FALSE)
  }
  if (!is.character(answer)) {
    cat("class(answer3_2) is not character\n")
    return(FALSE)
  }
  answer.ref <- paste(1:100, "+", seq(1, by = 2, length.out = 100))
  if (length(answer) != length(answer.ref)) {
    cat("length(answer3_2) is not 100\n")
    return(FALSE)
  }
  for(i in seq_along(answer.ref)) {
    if (!isTRUE(answer.ref[i] == answer[i])) {
      cat(sprintf("answer3_2[%d] is incorrect. The expected element is %s\n", i, answer.ref[i]))
      return(FALSE)
    }
  }
  TRUE
}