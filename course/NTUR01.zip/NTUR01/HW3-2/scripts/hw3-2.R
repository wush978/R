#' 同學在輸入`hw3_2_question()`，R 的螢幕上會顯示出一個R 的物件。
#' 請同學根據顯示結果，重現該R物件，並且將結果儲存到`answer3_2``

answer3_2 <- <請建立你看到的R物件>

#' 請不要更動以下的程式碼
#' 這些程式碼會檢查同學的答案的型態，並且可能帶有提示
stopifnot(is.character(answer3_2))
stopifnot(length(answer3_2) == 100)
