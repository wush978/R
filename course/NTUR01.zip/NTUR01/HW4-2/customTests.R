hw4_2_answer <- function() {
  e <- get("e", parent.frame())
  .e <- new.env()
  source_result <- try(source(e$script_temp_path, local = .e, encoding = "UTF-8"), silent = TRUE)
  if (class(source_result)[1] == "try-error") return(FALSE)
  question4 <- c(33, 42, 71, 26, 36, 1, 27, 45, 31, 23, 59, 45, 14, 79, 38, 
                 42, 62, 27, 82, 67, 4, 56, 52, 28, 25, 90, 80, 97, 73, 47, 1, 
                 33, 7, 9, 63, 45, 62, 51, 89, 43, 90, 43, 15, 73, 39, 65, 18, 
                 77, 71, 65, 98, 21, 42, 35, 73, 8, 44, 60, 44, 23, 28, 42, 68, 
                 25, 37, 29, 96, 52, 74, 31, 94, 8, 44, 16, 68, 75, 54, 46, 95, 
                 8, 44, 74, 5, 36, 44, 4, 30, 41, 51, 23, 68, 7, 28, 17, 49, 34, 
                 67, 65, 66, 79)
  names(question4) <- c("Claire", "Kyle", "Jasmine", "Kate", "Dylan", "Sarah", "Sophie", 
                        "Riley", "Thomas", "Laura", "Tom", "Hayley", "Connor", "Joshua", 
                        "Jordan", "Edward", "Emma", "Isabella", "Ryan", "Max", "Daniel", 
                        "Liam", "Josh", "Alex", "David", "Mia", "James", "Olivia", "Matt", 
                        "Chloe", "Ella", "Abbey", "Chris", "Andrew", "Jessica", "Callum", 
                        "Noah", "Ruby", "Sean", "Jacob", "Taylor", "Charlotte", "Hannah", 
                        "Nathan", "William", "Ethan", "Matthew", "Brayden", "Zoe", "Jackson", 
                        "Emily", "Jayden", "Ashleigh", "Nick", "Holly", "Claudia", "Zac", 
                        "Harry", "Nicole", "Natasha", "Grace", "Molly", "Lachlan", "Nicholas", 
                        "Lachie", "Jade", "Patrick", "Jake", "John", "Lauren", "Chelsea", 
                        "Julia", "Georgia", "Lucy", "Jess", "Erin", "Ebony", "Michael", 
                        "Jack", "Ben", "Will", "Courtney", "Bailey", "Amy", "Caitlin", 
                        "Sam", "Amber", "Stephanie", "Katie", "Maddy", "Amelia", "Oliver", 
                        "Aaron", "Tayla", "Bella", "Lily", "Caitlyn", "Luke", "Cody", 
                        "Samantha")
  
  answer <- .e$answer4_2
  if (is.null(answer)) {
    cat("Cannot find answer4_2 in your answer\n")
    return(FALSE)
  }
  if (!is.numeric(answer)) {
    cat("class(answer4_2) is not numeric\n")
    return(FALSE)
  }
  answer.ref <- question4[50]
  if (length(answer) != length(answer.ref)) {
    cat(sprintf("length(answer4_2) is not %d\n", length(answer.ref)))
    return(FALSE)
  }
  for(i in seq_along(answer.ref)) {
    if (!isTRUE(as.vector(answer.ref[i] == answer[i]))) {
      cat(sprintf("answer4_2[%d] is incorrect. The expected element is %s\n", i, answer.ref[i]))
      return(FALSE)
    }
    if (!isTRUE(as.vector(names(answer.ref)[i] == names(answer)[i]))) {
      cat(sprintf("names(answer4_2)[%d] is incorrect. The expected element is %s\n", i, names(answer.ref)[i]))
      return(FALSE)
    }
  }
  TRUE
}