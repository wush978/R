hw1_advanced1_test <- function() {
  e <- get("e", parent.frame())
  name.list <- paste0("answer", 1:5)
  answer1.ref <- mean(datasets::cars$speed)
  answer2.ref <- "a,b"
  answer3.ref <- "x,y"
  answer4.ref <- "n"
  answer5.ref <- "n"
  tryCatch({
    for(name in name.list) {
      if (!isTRUE(all.equal(
        sort(get(name, envir = globalenv())),
        sort(get(sprintf("%s.ref", name)))
      ))) stop(sprintf("%s is wrong! Try again.\n", name))
    }
    TRUE
  }, error = function(e) {
    cat(conditionMessage(e))
    FALSE
  })
}