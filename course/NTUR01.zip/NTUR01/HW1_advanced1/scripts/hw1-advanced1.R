#' 請同學依照指示撰寫R的expression計算以下的問題。
#' 請把程式碼寫在 <請填寫你的程式碼> 的部份。
#' 寫完之後請記得「存擋」 
#' 寫完之後請記得「存擋」 
#' 寫完之後請記得「存擋」
#' 然後在console輸入`submit()`讓老師檢查答案 
#' 所有的答案都要算對，才會算分

## 出題用程式碼

#' 這段的程式碼是老師要準備資料給同學做練習，請不要修改
#' 同學在作答時，應該先把以下的程式碼輸入到console中後再繼續
{
  dist <- cars$dist
  speed <- cars$speed
  question2.fun <- function(a, b) {
    a + b
  }
}


## 問題一
#' 請同學利用`mean`函數計算變數`speed`的平均值
answer1 <- mean(x = <請填寫你的程式碼>)

## 問題二
#' 請同學在輸入`args(question2.fun)`之後，
#' 把所有`question2.fun`的參數名稱，依序以逗號分隔，以字串的方式，放到變數`answer2`之中
#' 例如函數strsplit的參數，依序以逗號分隔後會是： x,split,fixed,perl,useBytes
answer2 <- <請填寫你的程式碼>

## 問題三
#' 請同學先輸入`?graphics::plot`來打開這個函數的說明頁面
#' 請同學將`graphics::plot`的參數名稱，以和問題二相同的方式，放到變數`answer3`之中
#' ps. `...`沒有名稱
answer3 <- <請填寫你的程式碼>

## 問題四
#' 請問同學，如果我們輸入`plot(x = dist, y = speed)`會不會發生錯誤？
#' 會的話，請在`answer4`中填入字串y，否則在`answer4`中填入字串n
answer4 <- <請填寫你的程式碼>

## 問題五
#' 請問同學，如果我們輸入`plot(x = dist, y = speed, xlab = "distance")`會不會發生錯誤？
#' 作答時請參考`answer3`的答案
#' 會的話，請在`answer5`中填入字串y，否則在`answer5`中填入字串n
answer5 <- <請填寫你的程式碼>
