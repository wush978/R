assign("root", .tmp.path <- tempfile(), envir = globalenv())
utils::unzip(normalizePath(file.path(lesPath, "sample.zip"), mustWork = TRUE), exdir = .tmp.path)
