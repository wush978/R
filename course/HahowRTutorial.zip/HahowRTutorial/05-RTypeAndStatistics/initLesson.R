q4 <- head(iris$Sepal.Length, 4)
