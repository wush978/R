g <- function(i) {
  element <- x[[i]]
  mean(element)
}