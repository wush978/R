test_f <- function() {
  f <- get("f", globalenv())
  isTRUE(all.equal(deparse(f), deparse(function(i) i + 1)))
}

