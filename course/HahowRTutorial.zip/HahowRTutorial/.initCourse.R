if (packageVersion("swirl") < package_version("101.5.5")) {
  stop("Please upgrade the version of swirl via: `install.packages('swirl', repos = 'http://wush978.github.io/R')`")
}

options(
  "SWIRL_TRACKING_SERVER_IP" = "api.datascienceandr.org,api2.datascienceandr.org",
  "SWIRL_COURSE_VERSION" = "v1.0",
  "repos" = c("http://wush978.github.io/R", "CRAN"="http://mran.revolutionanalytics.com/snapshot/2016-04-01")
)
