facebook.shareposts <- structure(list(data = list(structure(list(created_time = "2017-05-07T00:44:17+0000", 
    story = "Learning By Hacking shared Taiwan R User Group's post.", 
    id = "367749100085994_619187774942124"), .Names = c("created_time", 
"story", "id"))), paging = structure(list(cursors = structure(list(
    before = "NjE5MTg3Nzc0OTQyMTI0Ojk6MAZDZD", after = "NjE5MTg3Nzc0OTQyMTI0Ojk6MAZDZD"), .Names = c("before", 
"after")), `next` = "https://graph.facebook.com/v2.9/127749000711610_826146314205205/sharedposts?access_token=EAACEdEose0cBAEMxOZAsKWTc44FtZCsWoRZA3MGaBRgIWQVIpQhOOZCXjtQMtDhlZAj6Pm9X0Mig4mGKpXehESfJ5Iqrb0DJxBV03ks1HChl3hQNXbR4jTQOA9wCJdeFJXt4kYtR76ph91CZAPZCWX3r7ynM4lxOAzM2aqFngRZAX4gqi0P9EJygMWAxsbHChBkZD&pretty=0&limit=25&after=NjE5MTg3Nzc0OTQyMTI0Ojk6MAZDZD"), .Names = c("cursors", 
"next"))), .Names = c("data", "paging"))
