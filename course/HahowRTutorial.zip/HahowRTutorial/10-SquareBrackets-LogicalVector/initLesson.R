set.seed(1)
x <- rnorm(20)
