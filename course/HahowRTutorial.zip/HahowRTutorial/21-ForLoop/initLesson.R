ans <- readLines(file.path(lesPath, "..", "15-Create", "answer.txt"))

pred <- readLines(file.path(lesPath, "..", "15-Create", "predict.txt"))
pred2 <- rep("0", length(ans))
pred3 <- rep("1", length(ans))

