hw3_1_answer <- function(tax.src.url) {
  tryCatch({
    e <- get("e", parent.frame())
    .e <- new.env()
    source_result <- try(source(e$script_temp_path, local = .e, encoding = "UTF-8"), silent = TRUE)
    if (class(source_result)[1] == "try-error") return(FALSE)
    stopifnot(is.character(tax.src.url))
    stopifnot(length(tax.src.url) == 22)
    tax.src.url.ref <- c("https://ws.fia.gov.tw/001/upload/ias/ias103/103_166-G_20170121154636.csv", 
      "https://ws.fia.gov.tw/001/upload/ias/ias103/103_166-U_20170121154636.csv", 
      "https://ws.fia.gov.tw/001/upload/ias/ias103/103_166-W_20170121154636.csv", 
      "https://ws.fia.gov.tw/001/upload/ias/ias103/103_166-M_20170121154636.csv", 
      "https://ws.fia.gov.tw/001/upload/ias/ias103/103_166-T_20170121154636.csv", 
      "https://ws.fia.gov.tw/001/upload/ias/ias103/103_166-K_20170121154636.csv", 
      "https://ws.fia.gov.tw/001/upload/ias/ias103/103_166-H_20170121154636.csv", 
      "https://ws.fia.gov.tw/001/upload/ias/ias103/103_166-E_20170121154636.csv", 
      "https://ws.fia.gov.tw/001/upload/ias/ias103/103_166-C_20170121154636.csv", 
      "https://ws.fia.gov.tw/001/upload/ias/ias103/103_166-Z_20170121154636.csv", 
      "https://ws.fia.gov.tw/001/upload/ias/ias103/103_166-P_20170121154636.csv", 
      "https://ws.fia.gov.tw/001/upload/ias/ias103/103_166-F_20170121154636.csv", 
      "https://ws.fia.gov.tw/001/upload/ias/ias103/103_166-O_20170121154636.csv", 
      "https://ws.fia.gov.tw/001/upload/ias/ias103/103_166-J_20170121154636.csv", 
      "https://ws.fia.gov.tw/001/upload/ias/ias103/103_166-I_20170121154636.csv", 
      "https://ws.fia.gov.tw/001/upload/ias/ias103/103_166-Q_20170121154636.csv", 
      "https://ws.fia.gov.tw/001/upload/ias/ias103/103_166-N_20170121154636.csv", 
      "https://ws.fia.gov.tw/001/upload/ias/ias103/103_166-B_20170121154636.csv", 
      "https://ws.fia.gov.tw/001/upload/ias/ias103/103_166-A_20170121154636.csv", 
      "https://ws.fia.gov.tw/001/upload/ias/ias103/103_166-V_20170121154636.csv", 
      "https://ws.fia.gov.tw/001/upload/ias/ias103/103_166-D_20170121154636.csv", 
      "https://ws.fia.gov.tw/001/upload/ias/ias103/103_166-X_20170121154636.csv"
    )
    for(url in tax.src.url.ref) {
      if (!url %in% tax.src.url) {
        stop(sprintf("Incorrect tax.src.url. (%s is missing)", url))
      }
    }
    TRUE
  }, error = function(e) {
    message(conditionMessage(e))
    FALSE
  })
}
