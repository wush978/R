# 讓測試時不會執行以下的程式碼
if (identical(environment(), globalenv()) & identical(parent.frame(), globalenv())) { 

#' 接下來的作業會帶著同學走一次期末報告要作的事項。
#' 這裡，老師想要看看台灣的各鄉鎮在「經濟狀況」與「支持的政黨」有無相關。
#' 
#' ## 資料的收集
#' 
#' 我打算利用所得稅的資料來評估各鄉鎮的經濟狀況。
#' 
#' 首先，我們利用[政府資料開放平台](https://data.gov.tw)，在上面搜尋：
#' 「綜合所得稅各類所得金額各縣市鄉鎮村里統計表-縣市別」
#' 根據網站，政府開放的資料共有22筆，每個縣市單獨一筆。
#' 這裡我們想要用 R 一次下載所有的資料。
#' 
#' 由於網站上已經有提供彙整搜尋結果的檔案，所以我們不用寫爬蟲，而是直接處理該檔案。
#' 以下的網址是這個搜尋結果的CSV格式的彙整資料：

  tax.list.url <- "https://data.gov.tw/datasets/export/csv?type=dataset&order=last_update_time&qs=%E7%B6%9C%E5%90%88%E6%89%80%E5%BE%97%E7%A8%85%E5%90%84%E9%A1%9E%E6%89%80%E5%BE%97%E9%87%91%E9%A1%8D%E5%90%84%E7%B8%A3%E5%B8%82%E9%84%89%E9%8E%AE%E6%9D%91%E9%87%8C%E7%B5%B1%E8%A8%88%E8%A1%A8-%E7%B8%A3%E5%B8%82%E5%88%A5&uid="

#' 我們可以用`download.file`來下載這個連結，再用`read.csv`讀取檔案

  # 讓R產生一個暫存檔路徑，該檔案在R關閉後就會被刪除
  tax.list.path <- tempfile(fileext = ".csv") 
  # 下載連結的檔案到`tax.list.path`
  download.file(tax.list.url, destfile = tax.list.path, mode = "wb")

#' 我們可以用`tools::md5sum`這個函數來計算下載的檔案的MD5
#' MD5 是密碼學的一種雜湊演算法(可參考：<https://en.wikipedia.org/wiki/Cryptographic_hash_function>)
#' 實務上，我們可以利用MD5 演算法來計算檔案的內容，得到一個長度為32的HEX CODE
#' 只要檔案的內容有一點點變化，結果的HEX CODE就會有很大的差異。
#' 在下載檔案後，常常利用MD5來檢查檔案有沒有完整的被下載：

  # 檢查同學下載的檔案是否與老師期待的一致
  stopifnot(tools::md5sum(tax.list.path) == "49aaad7bf5a1702d536d8e0ab8e643c5")

#' 請同學用各種方法處理剛剛下載的檔案，
#' 列出「103年度」的「各類所得金額各縣市鄉鎮村里統計表-縣市別」中，
#' 能下載的CSV檔案「下載連結」，並且將這22個連結存到變數`tax.src.url`

  <請填寫你的程式碼>
  tax.src.url <- <請填寫你的程式碼>
    
#' 在同學成功建立變數`tax.src.url`後，請輸入`submit()`

  # 一些檢查與提示
  stopifnot(length(tax.src.url) == 22)
  stopifnot(is.character(tax.src.url))

}