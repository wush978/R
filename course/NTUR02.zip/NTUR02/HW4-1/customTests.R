hw4_1_answer <- function(ods.contents) {
  tryCatch({
    e <- get("e", parent.frame())
    .e <- new.env()
    source_result <- try(source(e$script_temp_path, local = .e, encoding = "UTF-8"), silent = TRUE)
    if (class(source_result)[1] == "try-error") return(FALSE)
    ods.contents.backup <- ods.contents
    names(ods.contents) <- basename(names(ods.contents))
    . <- lapply(names(ods.contents), charToRaw)
    . <- sapply(., length)
    if (any(. != 28)) {
      # BIG5
      names(ods.contents) <- iconv(names(ods.contents), from = "BIG5", to = "UTF-8")
      Encoding(names(ods.contents)) <- "UTF-8"
    }
    ods.contents.names.raw <- dget(gzfile(file.path(e$path, "ods.contents.names.raw.gz")))
    ods.contents <- ods.contents[sapply(ods.contents.names.raw, function(.) {
      .r <- rawToChar(.)
      Encoding(.r) <- "UTF-8"
      .r
    })]
    stopifnot(sapply(ods.contents, digest::digest) == c("87216a3ff7c5fb6c925461a14a890a85", "342f64cbfa7d314b69754fa1af44f55b", 
      "b2161ef019391f77c9cbe0344d497924", "1e11186cf3ca774995c8c7a09236758c", 
      "db23e84fcbf210cd7db72d49957586e1", "0ee367da30fc663dcf0e2f13d3e8b0dd", 
      "d6b7db87057e7c1deb8f99c63fc0a58a", "6c859146fe17cb8d868922492d5e3ee7", 
      "0468fb0ec6d81f0568c834dfb9774fa3", "ca00038864eca00f1c70d4b8f71b735a", 
      "6ed379d830cd8bf2d2a931bdf6ab88c1", "8a4d7ec892780d74d7030d2e7357e4fb", 
      "75c3204c4bf04ca3195109ba0f24fe75", "65dac6197913158716a2c59fa6d9013b", 
      "ddcc578f21e52e541ffd03cb27ee3b32", "27826a7558d84d7e3700a88d63858600", 
      "12e9c90eece9482ab98fc31f1674b8a6", "1bfb0d61618d0a976a95d175ab8abee5", 
      "9bee67668ddfebfba62b730ebbc8b39f", "ecb0f2bced99586b2eecce37b3ed20b3", 
      "985d305be43484e91e88e5b3690301d2", "2e9e3328fbd73f446ef1440fd79368b7", 
      "e3eb630fab4e82a8e11851964809275a", "89f57d887c2605af182df3faefe9e08e", 
      "bd8ed9806bc02844088cf159433d0c24", "eba524fdbdaf845ffaa6f75b3c872a04", 
      "cc5047bf6d68cdcb59c562c159c96f58", "f0da085718f05a56d2acf00869d49ee8", 
      "42eda90ea533067220dc264cebe7fc63", "713c996456747c0ec2068731f606764d", 
      "50b4db567ff43ec81c6ad4079f69db92", "62c26c63f6859c5076d51382854d3687", 
      "1c5ef267a6998f7e24db75a7f29257bc", "b6096848aac99aa81e9462ac3ab3dac7", 
      "302bd96b1c4a2d6bdb6726b60fb76b57", "2798136279e0fb1b3b97434005a34077", 
      "ea437b950ae47b2a47d75549bf880bbf", "03f3d027cf5ed328e1cf9680ccb7bbe7", 
      "f793056b29aead75f7d089afb836da11", "10539101bd60d36f0bc0363cf0952c3a", 
      "f13989617edcd842e00e4e69a269a217", "39a8ec69386431a0594b47091973f29c", 
      "eb61e5bcc096bd9800eb81843d500768", "5eb55ad252f6ab430fcebada8639e29f", 
      "5e93a5bd1b019b2ea78f8dfbed10f038", "9bac2bd4681292be16cfaf4654703961", 
      "297dc429b610c5406a5a1d35e4905c4a", "da6068c7f1b09c735f9034f49b6fb8ad", 
      "550e9138c0a05164854506d526a02ad5", "6edba3fe7ddd7533490be01f6464c3bc", 
      "c4df212a5cb91e75b37ad9fe86173cd1", "530b52b62d6aa88d556474bf4cd01b70", 
      "d3c342ba405c97f65e63daedea40dcfa", "21afb7e6fb2f915551de65a41ca5383e", 
      "0b71d55c9741e8188183b317589b5539", "ac456132d5de935bd57247b243f7ea36", 
      "e21f18b91f710780fead38ac9b1d30f5", "f44a44e1449ee47e8a0bff9e8112e0f6", 
      "565887098751a09a9a2018b339f845b5", "09ff410bf54a0ff3ad0448f25550d404", 
      "4aaa662093f773c47c582dd639aa9629", "9e896e2c6c28aa776922ef4628b1f5be", 
      "263b06872f82161f38ccc296712da7ec", "ee1cc96f495c3ae58ad5c0067630b4fd", 
      "6f81f3cba77ab334f692265a5488270c", "2af3672dd7a75eb56db1b5c7fc483268", 
      "0fbc0cd0b0ec8980b65a88345a023e9f", "2c7a3e9e18a31f556f75c164e6ae2228"
      ))
    TRUE
  }, error = function(e) {
    message(conditionMessage(e))
    FALSE
  })
}
