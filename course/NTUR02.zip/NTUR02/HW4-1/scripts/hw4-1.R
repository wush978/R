# 讓測試時不會執行以下的程式碼
if (identical(environment(), globalenv()) & identical(parent.frame(), globalenv())) { 

#' 這個關卡，我們要從中選會下載總統選舉的各鄉鎮的投票結果
#' 請同學利用依照以下的只是下載.zip檔案，並且解壓縮

  ## 下載檔案
  # 利用R 產生一個暫存檔案的路徑
  tmp.path <- tempfile(fileext= ".zip")
  download.file("http://db.cec.gov.tw/histFile?voteCode=20160101P1A1&resourceCode=S3", destfile = tmp.path, mode = "wb")
  stopifnot(tools::md5sum(tmp.path) == "34412d6d18c019100172bf765b49173f")
  
  ## 解壓縮
  # R 內部有 `unzip` 函數可以處理 ".zip" 檔案
  # 我們可以先列出檔案的內容
  (file.list <- unzip(tmp.path, list = TRUE))
  # 這裡的`file.list`是BIG-5編碼的檔案名稱，為了跨平台，
  #（某些同學用Mac、可能沒有同學在用但是老師有在用的Linux）
  # 所以這裡我們把名稱改成UTF-8編碼做閱讀
  iconv(file.list$Name, from = "BIG5", to = "UTF-8")
  # 但是還是要先用BIG5做解壓縮
  
  # 我們建立一個放置解壓縮後的檔案的目錄
  exdir <- tempfile()
  dir.create(exdir)
  # 解壓縮
  unzip(tmp.path, exdir = exdir)
  # 非windows的要對檔案名稱做轉編碼
  if ( l10n_info()$MBCS & ! l10n_info()$`UTF-8`) {
    # windows 的同學不用做動作
    # 只要設定變數`exdir2`為`exdir`底下的目錄名稱
    exdir2 <- dir(exdir, full.names = TRUE)
  } else {
    # mac / linux 的同學要更改檔案名稱
    # 先取得第一層目錄的名稱
    . <- dir(exdir, full.names = TRUE)
    # 取得這個目錄的轉碼名稱，並且先建立這個目錄。
    exdir2 <- iconv(., from = "BIG5", to = "UTF-8")
    dir.create(exdir2)
    # 再取得目錄底下的檔案清單（這個`.zip`檔案中有一層目錄，所以要`dir`兩次）
    . <- dir(., full.names = TRUE)
    # 利用`iconv`轉換編碼後再使用`file.rename`更改名稱
    file.rename(., iconv(., from = "BIG5", to = "UTF-8"))
  }
  # 取得所有下載的檔案清單
  ods.list <- dir(exdir2, full.names = TRUE)
  # 經過Google可以發現，readODS套件可以讀取.ods格式的檔案
  # 請同學安裝並使用`readODS`套件，並且使用`read.ods`讀取這些檔案
  # 請建立變數`ods.contents`，它是一個滿足以下條件的named list：
  # 1. `names(ods.contents)`的值要等同於`ods.list`
  # 2. 對於任意的整數`i`，ods.contents[[i]] 即是 `read.ods(names(ods.contents)[i], <填寫適當的參數>)` 的結果
  # 註：這個讀檔案的動作，在老師的電腦上跑了若干分鐘。請同學有耐心。
  # 若同學使用的是迴圈，可以在`for`迴圈之中加上`print`指令來了解目前R 執行的進度。
  # 舉例來說： 
  # ```
  # for(i in 1:length(ods.list)) {
  #   print(i)
  #   ods.contents[[i]] <- ...
  # }
  # 就可以透過螢幕上的1, 2, ... 了解到目前R讀取檔案的進度了
  # 這個技巧在執行比較花時間的程式時很常用
  library(readODS)
  ods.contents <- <請填寫你的程式碼>
  
  # 建立好`ods.contents`之後請同學嘗試著執行以下的檢查
  # 或是跳到最下面，依照老師的只是將`ods.contents`直接儲存到硬碟
  stopifnot(is.list(ods.contents))
  stopifnot(names(ods.contents) == ods.list)
  stopifnot(is.list(ods.contents[[1]]))
  stopifnot(length(ods.contents[[1]]) == 1)
  # 檢查是否每一個element都是長度是1的list
  # 這代表是否每一個ods都只有一個sheet
  stopifnot(sapply(ods.contents, length) == 1) 
  # 檢查同學讀出來的data.frame中的row數量是否有誤
  stopifnot(
    sort(sapply(ods.contents, function(.) nrow(.[[1]]))) ==
      c(8L, 9L, 10L, 12L, 12L, 13L, 18L, 18L, 18L, 18L, 19L, 19L, 19L, 
      19L, 22L, 24L, 24L, 26L, 28L, 29L, 32L, 35L, 35L, 39L, 43L, 44L, 
      49L, 80L, 92L, 108L, 126L, 130L, 170L, 170L, 186L, 195L, 210L, 
      235L, 251L, 262L, 282L, 298L, 299L, 319L, 381L, 404L, 414L, 414L, 
      474L, 490L, 492L, 502L, 504L, 514L, 572L, 621L, 661L, 700L, 794L, 
      935L, 1067L, 1081L, 1107L, 1353L, 1566L, 1571L, 1844L, 2448L)
  )
  # 請同學輸入`saveRDS(ods.contents, file = "<同學電腦的某處>)"`
  # 將ods.contents的資料先儲存到硬碟上。
  # 之後的關卡，會要同學使用`readRDS`直接讀取這的變數，就不用重新跑`read.ods`
  # 完成之後輸入`submit()`
}