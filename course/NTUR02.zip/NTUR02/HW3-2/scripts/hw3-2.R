# 讓測試時不會執行以下的程式碼
if (identical(environment(), globalenv()) & identical(parent.frame(), globalenv())) { 
  
#' 請同學在下載上一個單元列出的22個下載網址的的檔案之後，
#' 利用`tools::md5sum`計算這22個檔案的MD5
#' 並且把結果存到變數`tax.md5`

  tax.md5 <- <你的程式碼>

  # 一些檢查與提示
  stopifnot(is.character(tax.md5))
  stopifnot(nchar(tax.md5) == 32)
  stopifnot(length(tax.md5) == 22)

#' 在同學成功建立變數`tax.md5`後，請輸入`submit()`

}
