hw3_2_answer <- function(tax.md5) {
  tryCatch({
    stopifnot(is.character(tax.md5))
    stopifnot(length(tax.md5) == 22)
    tax.md5.ref <- c("e73eb0c79395667561d0cf425a16e5b1", "08e08f9b85f093d2e8c28ad16865e173", 
                     "0ccdabaa1e55410bb56aa042e67e8f14", "ac4b9bad2129434633cfe5758f6af2be", 
                     "0f558b60ab007ef1dc64efb58d82f062", "7eeb894a8c084c7fce7254fe3226ba28", 
                     "ec48580757414c24a64386a724902daf", "017e0115dec962e70bdc836157176fbd", 
                     "a87e52133859213781fb6d29cfdfb132", "ae7458d53f92a7983fbe8dcd36eee56f", 
                     "3237bf9ca52c652b094c5687dc905840", "d9f8950dc445dea4a2cb9ad805cb1bc5", 
                     "251730c59d853e42369eb1b2545f1cca", "c1d5317a51d57c3a9fbc39545ea462c0", 
                     "1b46fa3975219826c943ca5d35bbb5e1", "135306aa53f7a851aebc2587e54b5c2d", 
                     "b617ba7d3c4f7e6f20b2f23f0bb220e1", "15d9da2af695c74e0f9e0fe050b7fc2d", 
                     "01638618857f89004a2a71c533226021", "4321980e6cb448a939c0645785c37654", 
                     "49cec5f9f65cd78694d3774fc40fb17f", "14aa473e3277bbc48ca0da909bb5cdae"
    )
    for(md5 in tax.md5.ref) {
      if (!md5 %in% tax.md5) {
        stop(sprintf("Incorrect tax.md5. (%s is missing)", md5))
      }
    }
    TRUE
  }, error = function(e) {
    message(conditionMessage(e))
    FALSE
  })
}
