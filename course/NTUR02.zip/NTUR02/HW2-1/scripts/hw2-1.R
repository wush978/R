#' 這個作業會讓同學練習從一個XML檔案中萃取資訊
#' 資料來源：<https://data.gov.tw/dataset/44062>
#' 
#' 以下是資料的說明（備份自上述網址）：
#' 
#' 資料集描述: 台灣就業通網站職缺清單
#' 主要欄位說明: OCCU_DESC(職務名稱)、WK_TYPE(職務性質)、
#'   CJOB_TYPE(職務大類別代碼)、CJOB_NAME1(職務大類別名稱)、
#'   CJOB_NO(職務小類別代碼)、CJOB_NAME2(職務小類別名稱)、
#'   AVAILREQNUM(雇用人數)、STOP_DATE(應徵截止日期)、
#'   JOB_DETAIL(工作內容)、CITYNAME(工作地點)、EXPERIENCE(工作經驗)、
#'   WKTIME(工作時間)、SALARYCD(核薪方式)、EDGRDESC(最低學歷要求)、
#'   URL_QUERY(職缺資料URL)、COMPNAME(公司名稱)、TRANDATE(職缺更新日期)
#' 提供機關: 勞動部勞動力發展署

## Step 1: 檢視資料

#' 老師已經事先將資料下載並放到課程安裝包之中。
#' 變數`occu.path`儲存了該檔案在同學電腦中的位置。
#' 同學可以使用`file.edit(occu.path)`來在Rstudio或是預設的編輯器中，
#' 打開該檔案。
#' ps. 請不要修改該檔案。如果動到，可以重開課程，該檔案的內容則會復原。

## Step 2: 請載入套件 xml2 
library(xml2)

## Step 3: 使用 xml2 套件解析該檔案中的XML
doc <- xml2::read_xml(occu.path, encoding = "UTF-8")

## Step 4: 
#' 請同學先找出這份文件中，所有職缺所需要的最低學歷要求
#' 然後將這些要求以character vector的形式儲存到變數`answer.edgrdesc`
#' 提示：取得節點之後，可以用`xml2::xml_text`將節點的資料以文字型態取出
#' 注意：第一個元素應該是第一個相關節點的結果，第二個元素應該是第二個相關節點的結果
answer.edgrdesc <- <請填寫你的程式碼>

stopifnot(is.character(answer.edgrdesc))
# 變數 `.x1` 的值是"專科"。這種寫法是要避免在windows上發生編碼問題
.x1 <- rawToChar(as.raw(c(0xe5, 0xb0, 0x88, 0xe7, 0xa7, 0x91)))
Encoding(.x1) <- "UTF-8"
stopifnot(answer.edgrdesc[1] == .x1)
stopifnot(answer.edgrdesc[2] == .x1)
## Step 5:
#' 請同學先找出這份文件中，所有職缺的僱用人數
#' 然後將這些要求以numeric vector的形式儲存到變數`answer.availreqnum`
#' 提示：取得節點之後，可以用`as.numeric`將文字型態做轉換
#' 注意：第一個元素應該是第一個相關節點的結果，第二個元素應該是第二個相關節點的結果
answer.availreqnum <- <請填寫你的程式碼>
stopifnot(is.numeric(answer.availreqnum))
stopifnot(answer.availreqnum[1] == 1)
stopifnot(answer.availreqnum[2] == 1)

## Step 6:
#' 請同計算出各種最低學歷要求所對應的職缺數
#' 把結果放到變數`answer.edgrnum`，
#' 並且在`names(answer.edgrnum)`中放入對應的最低學歷要求。
#' 舉例來說：`c("不拘" = 10, "博士" = 10, ...)`
#' 提示：同學可以假設`answer.edgrdesc`與`answer.availreqnum`的順序是有關的
#' 所以可以利用`answer.availreqnum[answer.edgrdesc == "國小"]`取得所有最低學歷要求是國小的職缺數
#' 接著搭配for迴圈做處理。
#' 或是使用`split`函數。
#' 老師不建議同學一個一個數。
answer.edgrnum <- <請填寫你的程式碼>

stopifnot(is.numeric(answer.edgrnum))
# 確定同學的答案包含所有種類的最低學歷要求
stopifnot(sort(names(answer.edgrnum)) == sort(unique(answer.edgrdesc)))
# 確定總數是一致的
stopifnot(sum(answer.edgrnum) == sum(answer.availreqnum))
# 已知國小的職缺有9個
# 變數 `.x2` 的值是"國小"。這種寫法是要避免在windows上發生編碼問題
.x2 <- rawToChar(as.raw(c(0xe5, 0x9c, 0x8b, 0xe5, 0xb0, 0x8f)))
Encoding(.x2) <- "UTF-8"
stopifnot(answer.edgrnum[.x2] == 9)

## Step 7
#' 完成你的答案，並且執行上面以`stopifnot`開頭的expressions做檢查
#' 如果發生錯誤，可以參考`stopifnot`中使用的函數做提示，去抓自己哪邊出錯。
#' 若都沒有錯誤後，請存檔
#' 請存檔
#' 請存檔
#' 
#' 然後回到console輸入`submit()`
