hw2_1_answer <- function() {
  e <- get("e", parent.frame())
  .e <- new.env()
  source_result <- try(source(e$script_temp_path, local = .e, encoding = "UTF-8"), silent = TRUE)
  if (class(source_result)[1] == "try-error") return(FALSE)
  if (tools::md5sum(globalenv()$occu.path) != "9f3e7ecb50fa3fab14d503adee29d436") {
    message("The content of occu.path is changed. Please restart the course.")
    return(FALSE)
  }
  type.checks <- c(
    "answer.edgrdesc" = "character",
    "answer.availreqnum" = "numeric",
    "answer.edgrnum" = "numeric"
  )
  for(name in names(type.checks)) {
    if (is.null(.e[[name]])) {
      message(sprintf("%s is not found", name))
      return(FALSE)
    }
    if (!get(sprintf("is.%s", type.checks[name]), envir = baseenv())(.e[[name]])) {
      message(sprintf("%s is not a %s vector", name, type.checks[name]))
      return(FALSE)
    }
  }
  doc <- xml2::read_xml(occu.path, encoding = "UTF-8")
  answer.edgrdesc <- xml2::xml_find_all(doc, "//EDGRDESC")
  answer.edgrdesc <- xml2::xml_text(answer.edgrdesc)
  answer.availreqnum <- xml2::xml_find_all(doc, "//AVAILREQNUM")
  answer.availreqnum <- xml2::xml_text(answer.availreqnum)
  answer.availreqnum <- as.numeric(answer.availreqnum)
  answer.edgrnum <- split(answer.availreqnum, answer.edgrdesc)
  answer.edgrnum <- sapply(answer.edgrnum, sum)
  answer.edgrnum <- answer.edgrnum[sort(names(answer.edgrnum))]
  if (is.null(names(.e$answer.edgrnum))) {
    message("answer.edgrnum has no names")
    return(FALSE)
  }
  for(edgr in names(answer.edgrnum)) {
    if (!edgr %in% names(.e$answer.edgrnum)) {
      message(sprintf("names(answer.edgrnum) does not contain %s", edgr))
      return(FALSE)
    }
  }
  .e$answer.edgrnum <- .e$answer.edgrnum[sort(names(.e$answer.edgrnum))]
  value.checks <- list(
    "answer.edgrdesc" = answer.edgrdesc,
    "answer.availreqnum" = answer.availreqnum,
    "answer.edgrnum" = answer.edgrnum
  )
  for(name in names(value.checks)) {
    .ans <- value.checks[[name]]
    if (length(.e[[name]]) != length(.ans)) {
      message(sprintf("length(%s) is incorrect. The expected answer is %d", name, length(.ans)))
      return(FALSE)
    }
    if (is.null(names(.ans))) {
      for(i in seq_along(.ans)) {
        if (.ans[i] != .e[[name]][i]) {
          message(sprintf("%s[%d] is incorrect. The expected answer is %s", name, i, as.character(.ans[i])))
          return(FALSE)
        }
      }
    } else {
      for(.n in names(.ans)) {
        if (.ans[.n] != .e[[name]][.n]) {
          message(sprintf("%s[\"%s\"] is incorrect. The expected answer is %s", name, .n, as.character(.ans[.n])))
          return(FALSE)
        }
      }
    }
  }
  return(TRUE)
}
