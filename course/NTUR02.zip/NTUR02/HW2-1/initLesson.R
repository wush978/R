occu.path <- tempfile(fileext = ".xml")
if (!file.copy(
  normalizePath(file.path(lesPath, "A17000000J-030144-pME.xml"), mustWork = TRUE),
  occu.path
)) stop(sprintf("Cannot copy the XML file to %s. Please ask the teacher on https://gitter.im/wush978/DataScienceAndR", occu.path))
assign("occu.path", occu.path, envir = globalenv())
