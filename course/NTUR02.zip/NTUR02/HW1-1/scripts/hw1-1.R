#' 這個作業會讓同學練習跑一個 shiny application


# 步驟一
#' 首先，請同學請直接在 R 中安裝 shiny 套件

library(shiny)
#' 檢查套件的版本
stopifnot(packageVersion("shiny") >= package_version("1.0.3"))

# 步驟二
#' 以下的程式碼是一個關於統計的模擬。
#' `x <- rbinom(1000, input$n, 0.5)`會讓變數x儲存1000個一個Binomial distributed的隨機變數
#' 根據統計理論，當`input$n`很大的時候，`x`的分佈會很接近Normal distribution
#' 因此我們用`hist`函數來畫圖觀察`x`的分佈，
#' 再用`lines`函數來畫出Normal distribution的機率密度函數做比較
#' 關於統計的背景知識，同學可以自行閱讀binomial distribution做補足
if (identical(environment(), globalenv()) & interactive()) { # 避免在測試的時候執行
  shinyApp(
    ui = fluidPage(
      numericInput("n", "sample size", 10),
      plotOutput("plot")
    ),
    server = function(input, output) {
      output$plot <- renderPlot({
        # binomial distribution 中出現positive的機率
        p <- 0.5
        # 讓變數x儲存1000個一個Binomial distributed的隨機變數
        x <- rbinom(1000, input$n, p)
        # 繪製長條圖，並且讓y軸代表density，並且把繪製圖形的細節輸出到變數`.p`
        .p <- hist(x, freq = FALSE)
        # 根據`.p`，將目前圖中的x軸範圍定位，並且切成100等分
        .x <- seq(max(.p$breaks), min(.p$breaks), length.out = 100)
        # 計算.x對應的，並且也是理論上與x接近的normal distribution的機率密度函數的值
        # 其中normal distribution的平均值與標準差會和binomial distribution的參數有關
        # .x + 0.5 是所謂的 continuity correction (有興趣的同學可以比較有放+0.5與沒有的差別)
        .d <- dnorm(.x + 0.5, input$n * p, sqrt(input$n * p * (1 - p)))
        # 畫圖
        lines(.x, .d)
      })
    }
  )
}

# 動作三

#' 請同學修改上述的程式碼，
#' 在shiny application中多放一個sliderInpur，讓操作的人可以控制上面一段程式碼中的變數`p`，
#' 因為變數`p`也是rbinom的prob參數`，所以範圍請限制在0與1之間。
#' 最後產生結果的程式碼儲存為一個附檔名稱為`.R`的檔案，上傳到ceiba上的作業HW1-1。
