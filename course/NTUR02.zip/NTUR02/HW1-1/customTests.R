hw1_1_answer <- function() {
  TRUE
}