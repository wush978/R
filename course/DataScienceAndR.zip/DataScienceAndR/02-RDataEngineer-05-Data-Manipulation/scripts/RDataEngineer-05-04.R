# 我們定義gain為arr_delay - dep_delay。
# 請算出1 月份平均的gain。
answer04.1 <- local({
  # 請填寫你的程式碼。
})
stopifnot(class(answer04.1) == "numeric")
stopifnot(length(answer04.1) == 1)

# 請問是不是carrier為AA的飛機tailnum都有AA字眼呢？
answer04.2 <- local({
  # 請填寫你的程式碼。
  # 請給出你的答案： TRUE or FALSE。
})
stopifnot(class(answer04.2) == "logical")
stopifnot(length(answer04.2) == 1)

# 請問dep_time介於 2301至2400之間的平均dep_delay為多少呢?
answer04.3 <- local({
  # 請填寫你的程式碼。
})
stopifnot(class(answer04.3) == "numeric")
stopifnot(length(answer04.3) == 1)

# 請問dep_time介於 1至 100之間的平均dep_delay為多少呢?
answer04.4 <- local({
  # 請填寫你的程式碼。
})
stopifnot(class(answer04.4) == "numeric")
stopifnot(length(answer04.4) == 1)

# 完成後請存檔，並回到console輸入`submit()`。
