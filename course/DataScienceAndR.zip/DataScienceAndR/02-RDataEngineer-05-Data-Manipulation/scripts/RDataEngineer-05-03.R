answer03 <- local({
  # 請用filter挑出dep_time為NA的資料，
  # 你可以用is.na，
  result1 <-
  # 並請用select從result1挑出year, month 和day。
})
# 完成後，請回到console輸入`submit()`。
