answer02 <- local({
  # 請從flights篩選出dep_delay > 0的資料，
  target <- # 請填寫你的程式碼。
  nrow(target)
})
# 完成後請在console輸入`submit()`。
