# 請先用`substring`擷取site_id的前三個字，取得台灣的縣市級行政區名稱(取名為city)。
# 然後利用filter取出自己感興趣的行政區。
# 透過對city, age 做分組加總。
# 再利用group_by分組對人數取平均，算出各年齡的人數比例。
# 最後利用ggplot來繪圖。
