# 1. 利用dplyr::filter 篩選出自己所居住的里。
# 2. 利用group_by + summarise 依據性別做加總。
# 3. 利用ggplot2 繪製長條圖。
