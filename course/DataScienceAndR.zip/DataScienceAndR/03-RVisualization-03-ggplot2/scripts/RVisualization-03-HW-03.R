# 1. 利用dplyr::filter 篩選出自己居住的里。
# 2. 利用ggplot2 依據人數與年齡繪製，依據年齡排序，繪製散佈圖與折線圖(geom_line)。
