answer01 <- local({
  # 請在此填寫你的程式碼。
})
# 結束之後請回到console輸入`submit()`。
