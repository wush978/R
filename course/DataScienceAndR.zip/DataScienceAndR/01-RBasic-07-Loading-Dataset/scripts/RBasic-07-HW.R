#' 請同學用這章節所學的技巧，讀取名為`orglist.path`的檔案。
#' 資料來源：<http://data.gov.tw/node/7307>

# <你可以在這裡做不同的嘗試>
answer <- <你的程式碼>
